setInterval(()=>{

let imgs = document.querySelectorAll('img');
imgs.forEach((a,i)=>{
    a.src = 'https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2FMjAyMjA1MTRfMjU2%2FMDAxNjUyNDkxOTMzNzkz.Wn5plhf2w5QlxifG7UltCBImA93tI_2NIHD9tAoR7FEg.lp3c-lfPaDTVfzxf3Akw2VmyE4151bP5EhQ6_LNPsXkg.JPEG.hasun-%2FIMG_2348.jpg&type=sc960_832'
})

}, 500)